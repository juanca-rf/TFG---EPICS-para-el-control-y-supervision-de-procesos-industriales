# Autor: Juan Carlos Ruiz Fernández
# Objetivo: IOC del Trabajo Fin de Grado Análisis del software EPICS para el control y supervisión de procesos industriales
# Universidad de Granada, Escuela Técnica Superior en Ingeniería Informática y Telecomunicaciones
# Fecha de entrega: 7 de agosto de 2023

# Para ejecutar este IOC, se debe tener instalado EPICS y el módulo OPC UA. Además, para que obtenga lecturas de datos, necesita que PLCSim esté en funcionamiento y NetToPLCsim abierta una IP. Esa IP debe coincidir con la que aparece en el archivo iocBoot/iocprocesadorPiezas/st.cmd.

# Entonces, ejecutar los siguientes comandos desde este directorio y en este orden:
make 
cd iocBoot/iocprocesadorPiezas/
./st.cmd
